import React from 'react';

const Thankyou = () => {
    return (
        <div>
            <h2>Thank You</h2>
        </div>
    );
};

export default Thankyou;
