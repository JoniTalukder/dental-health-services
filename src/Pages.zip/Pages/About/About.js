import React from 'react';

const About = () => {
    return (
        <div className='container'>
            <h2>Joni Talukder</h2>
            <p>I completed my B.Sc(Hons) in 2010. But Still, struggle for my bright future. I have already been offered a great job but I want to develop my carrier as a  Full Stack Developer. That is why I will wait to complete the full course with a successfully good understanding. Pray for me for my Bride future.</p>
        </div>
    );
};

export default About;